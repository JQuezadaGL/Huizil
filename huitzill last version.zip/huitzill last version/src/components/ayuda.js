import React, { Component } from 'react';
import { Grid, Cell, List, ListItem, ListItemContent } from 'react-mdl';


class Ayuda extends Component {
  render() {
    return(
      <div >
        <div><h1>Ayuda</h1></div>
      </div>
    )
  }
}

export default Ayuda;