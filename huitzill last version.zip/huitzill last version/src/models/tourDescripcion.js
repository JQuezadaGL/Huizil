export default {
    tour: '',
    qty: '',
    origen: '',
    destino: '',
    hospedaje: '',
    transporte: '',

    fecha_ida_salida: '',
    hora_ida_salida: '',
    sitio_ida_salida: '',

    fecha_vuelta_salida: '',
    hora_vuelta_salida: '',
    sitio_vuelta_salida: '',

    fecha_ida_llegada: '',
    hora_ida_llegada: '',
    sitio_ida_llegada: '',

    fecha_vuelta_llegada: '',
    hora_vuelta_llegada: '',
    sitio_vuelta_llegada: '',

    status: "activo",
    fecha_registro: new Date()
}