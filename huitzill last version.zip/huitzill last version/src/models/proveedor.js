export default {
    tipo: '',
    tipo_desc: '',
    proveedor: '',
    contacto: '',
    telefono: '',
    ext: '',
    email: '',
    web: '',
    pais: '',
    estado: '',
    ciudad: '',
    comision: '',
    status: 'activo',
    fecha_reg: new Date()
}