export default {
    id_expediente: null,
    id_price: null,
    comentario: null,
    venta: "abierta",
    fecha_venta: new Date()
}