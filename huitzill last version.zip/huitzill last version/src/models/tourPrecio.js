export default {
    id_tour: null,
    habitacion: '',
    acceso: '',
    costo: '',
    status: "activo",
    descripcion: '',
    fecha_registro: new Date()
}

// descripcion: "Habitacion " + var_habitacion +" + Acceso " + var_acceso,
