export default {
    id_expediente: null,
    montoPago: '',
    datePago: '',
    dateCancel: '',    
    cuentaPago: '',
    tipoPago: '',
    status: "active",
    reffPago: '',
    commPago: '',
    cancelComments: '',
    fecha_registro: new Date()
}