export default {
    tour: "",
    medio: "",
    categoria: "",
    paxs_adulto: "",
    paxs_junior: "",
    paxs_menor: "",
    pax_infante: "",
    id_cliente: "",
    id_tour: "",
    comentarios: "",
    venta: "none",
    expediente: "open",
    pago: "none",
    user_id: "Un marcianito",
    status: "¡Nuevo!",
    fecha_alta: new Date()
}